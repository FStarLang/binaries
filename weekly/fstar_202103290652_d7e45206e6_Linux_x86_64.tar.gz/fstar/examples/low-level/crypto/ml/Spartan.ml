
open Prims

type u8 =
FStar_UInt8.t


let keyExpansion : u8 FStar_Buffer.buffer  ->  u8 FStar_Buffer.buffer  ->  u8 FStar_Buffer.buffer  ->  Prims.unit = (fun key w sb -> ())


let cipher : u8 FStar_Buffer.buffer  ->  u8 FStar_Buffer.buffer  ->  u8 FStar_Buffer.buffer  ->  u8 FStar_Buffer.buffer  ->  Prims.unit = (fun out input w sb -> ())




