# Doubly Linked List

This is a work in progress by [Jay Bosamiya](https://github.com/jaybosamiya/),
with main development going on at [this repository](https://github.com/jaybosamiya/lowstar-dlist-trials).

When the code reaches maturity, it will be removed from here, and
moved into `ulib`, for use by others. Until such a point, it might
undergo large-scale changes with respect to the API, without notice.

Since the plan is to remove it from `examples` at some point soon, it
is placed in a separate directory, rather than the
`examples/data_structures` directory.
