In order to regenerate the interactive tests use

$ make accept

If you have leftovers from a previous session, you may need to clean the directory beforehand with

$ make clean
