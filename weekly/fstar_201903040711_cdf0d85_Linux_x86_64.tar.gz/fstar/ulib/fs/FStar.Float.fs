module FStar.Float
open Prims

type float = Prims.float
type double = float
