
open FStar_Buffer

let exit_success = 0
let exit_failure = 255
