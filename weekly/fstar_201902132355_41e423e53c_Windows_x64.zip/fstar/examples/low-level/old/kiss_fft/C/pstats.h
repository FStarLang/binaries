#ifndef PSTATS_H
#define PSTATS_H

void pstats_init();
void pstats_report();
 
#endif
