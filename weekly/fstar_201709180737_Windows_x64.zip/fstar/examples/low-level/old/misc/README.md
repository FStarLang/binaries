Alternative implementations
===========================

From what I understand, these two files are meant to override the (extracted)
files to re-direct the allocation operations to the standard OCaml GC'd heap.
