open Factorial

let _ = print_int (loopyFactorial2 3);;