module FStar_Exn

let raise = raise
