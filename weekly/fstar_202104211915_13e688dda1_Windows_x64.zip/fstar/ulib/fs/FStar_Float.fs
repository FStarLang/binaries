module FStar_Float
open Prims

type float = FSharp.Core.float
type double = float
