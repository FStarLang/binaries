module FStar_Mul
open Prims
let (*) = Prims.op_Multiply
