let _ = exit (A.main (Array.length Sys.argv) (FStar_Buffer.of_ocaml_array Sys.argv))
