open FStar_Monotonic_Heap

type 'a ref = 'a FStar_Monotonic_Heap.ref
