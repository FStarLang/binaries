// automatically generated file.
#define Z3_MAJOR_VERSION   4
#define Z3_MINOR_VERSION   8
#define Z3_BUILD_NUMBER    4
#define Z3_REVISION_NUMBER 10272

#define Z3_FULL_VERSION    "Z3 4.8.4.10272 d6df51951f4c master z3-4.8.4"
